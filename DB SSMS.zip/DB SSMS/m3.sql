create database m3

CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY IDENTITY(1,1),
    CustomerName NVARCHAR(100) NOT NULL,
    CustomerUsername NVARCHAR(50) UNIQUE NOT NULL,
    CustomerPassword NVARCHAR(255) NOT NULL,
    CustomerEmail NVARCHAR(100) NOT NULL,
    CustomerPaymentOption NVARCHAR(50) NOT NULL
);
INSERT INTO Customer (CustomerName, CustomerUsername, CustomerPassword, CustomerEmail, CustomerPaymentOption)
VALUES
('Ali Ahmed', 'ali.ahmed', 'pass123', 'ali.ahmed@gmail.com', 'Credit Card'),
('Sara Khan', 'sara.khan', 'pass123', 'sara.khan@yahoo.com', 'Debit Card'),
('Usman Sheikh', 'usman.sheikh', 'pass123', 'usman.sheikh@hotmail.com', 'Cash on Delivery'),
('Ayesha Siddiqui', 'ayesha.sid', 'pass123', 'ayesha.sid@gmail.com', 'Online Transfer'),
('Hassan Nawaz', 'hassan.nawaz', 'pass123', 'hassan.nawaz@gmail.com', 'PayPal'),
('Zara Malik', 'zara.malik', 'pass123', 'zara.malik@gmail.com', 'Cash on Delivery'),
('Bilal Qureshi', 'bilal.q', 'pass123', 'bilal.q@hotmail.com', 'Credit Card'),
('Fatima Tariq', 'fatima.tariq', 'pass123', 'fatima.tariq@yahoo.com', 'Debit Card'),
('Hamza Shah', 'hamza.shah', 'pass123', 'hamza.shah@gmail.com', 'Online Transfer'),
('Rabia Gul', 'rabia.gul', 'pass123', 'rabia.gul@gmail.com', 'PayPal'),
('Ahmed Iqbal', 'ahmed.iqbal', 'pass123', 'ahmed.iqbal@yahoo.com', 'Credit Card'),
('Sania Aslam', 'sania.aslam', 'pass123', 'sania.aslam@gmail.com', 'Debit Card'),
('Moiz Akhtar', 'moiz.akhtar', 'pass123', 'moiz.akhtar@hotmail.com', 'Cash on Delivery'),
('Shazia Farooq', 'shazia.farooq', 'pass123', 'shazia.farooq@gmail.com', 'Online Transfer'),
('Nabeel Zafar', 'nabeel.zafar', 'pass123', 'nabeel.zafar@gmail.com', 'PayPal'),
('Iqra Younus', 'iqra.younus', 'pass123', 'iqra.younus@yahoo.com', 'Cash on Delivery'),
('Fahad Raza', 'fahad.raza', 'pass123', 'fahad.raza@hotmail.com', 'Credit Card'),
('Maha Jalal', 'maha.jalal', 'pass123', 'maha.jalal@gmail.com', 'Debit Card'),
('Junaid Anwar', 'junaid.anwar', 'pass123', 'junaid.anwar@gmail.com', 'Online Transfer'),
('Samreen Niaz', 'samreen.niaz', 'pass123', 'samreen.niaz@gmail.com', 'PayPal'),
('Tariq Aziz', 'tariq.aziz', 'pass123', 'tariq.aziz@gmail.com', 'Credit Card'),
('Hina Shafiq', 'hina.shafiq', 'pass123', 'hina.shafiq@gmail.com', 'Debit Card'),
('Kamran Abbas', 'kamran.abbas', 'pass123', 'kamran.abbas@gmail.com', 'Cash on Delivery'),
('Lubna Arshad', 'lubna.arshad', 'pass123', 'lubna.arshad@yahoo.com', 'Online Transfer'),
('Zain Shahid', 'zain.shahid', 'pass123', 'zain.shahid@gmail.com', 'PayPal'),
('Asma Mirza', 'asma.mirza', 'pass123', 'asma.mirza@gmail.com', 'Cash on Delivery'),
('Rizwan Haider', 'rizwan.haider', 'pass123', 'rizwan.haider@gmail.com', 'Credit Card'),
('Shaista Tariq', 'shaista.tariq', 'pass123', 'shaista.tariq@hotmail.com', 'Debit Card'),
('Hammad Latif', 'hammad.latif', 'pass123', 'hammad.latif@yahoo.com', 'Online Transfer'),
('Sidra Noor', 'sidra.noor', 'pass123', 'sidra.noor@gmail.com', 'PayPal'),
('Adnan Javed', 'adnan.javed', 'pass123', 'adnan.javed@gmail.com', 'Credit Card'),
('Mariam Shafqat', 'mariam.shafqat', 'pass123', 'mariam.shafqat@gmail.com', 'Debit Card'),
('Saad Bashir', 'saad.bashir', 'pass123', 'saad.bashir@gmail.com', 'Cash on Delivery'),
('Rania Saeed', 'rania.saeed', 'pass123', 'rania.saeed@gmail.com', 'Online Transfer'),
('Talha Asghar', 'talha.asghar', 'pass123', 'talha.asghar@gmail.com', 'PayPal'),
('Kiran Yaseen', 'kiran.yaseen', 'pass123', 'kiran.yaseen@gmail.com', 'Cash on Delivery'),
('Waqas Nadeem', 'waqas.nadeem', 'pass123', 'waqas.nadeem@gmail.com', 'Credit Card'),
('Anum Zainab', 'anum.zainab', 'pass123', 'anum.zainab@gmail.com', 'Debit Card'),
('Farhan Ali', 'farhan.ali', 'pass123', 'farhan.ali@gmail.com', 'Online Transfer'),
('Mehwish Rauf', 'mehwish.rauf', 'pass123', 'mehwish.rauf@gmail.com', 'PayPal'),
('Adeel Khalid', 'adeel.khalid', 'pass123', 'adeel.khalid@gmail.com', 'Credit Card'),
('Bushra Khurram', 'bushra.khurram', 'pass123', 'bushra.khurram@gmail.com', 'Debit Card'),
('Saima Zafar', 'saima.zafar', 'pass123', 'saima.zafar@gmail.com', 'Cash on Delivery'),
('Umer Shahzad', 'umer.shahzad', 'pass123', 'umer.shahzad@gmail.com', 'Online Transfer'),
('Hira Qasim', 'hira.qasim', 'pass123', 'hira.qasim@gmail.com', 'PayPal'),
('Faisal Anwar', 'faisal.anwar', 'pass123', 'faisal.anwar@gmail.com', 'Credit Card'),
('Nida Rashid', 'nida.rashid', 'pass123', 'nida.rashid@gmail.com', 'Debit Card'),
('Zubair Altaf', 'zubair.altaf', 'pass123', 'zubair.altaf@gmail.com', 'Cash on Delivery'),
('Rafia Malik', 'rafia.malik', 'pass123', 'rafia.malik@gmail.com', 'Online Transfer'),
('Haroon Tariq', 'haroon.tariq', 'pass123', 'haroon.tariq@gmail.com', 'PayPal');

SELECT TOP 1 * FROM Seller;

select * from Customer
select * from Seller


CREATE TABLE Seller (
    SellerID INT PRIMARY KEY IDENTITY(1,1),
    SellerName NVARCHAR(100) NOT NULL,
    SellerUsername NVARCHAR(50) UNIQUE NOT NULL,
    SellerPassword NVARCHAR(255) NOT NULL,
    SellerEmail NVARCHAR(100) NOT NULL,
    SellerPaymentOption NVARCHAR(50) NOT NULL
);

INSERT INTO Seller (SellerName, SellerUsername, SellerPassword, SellerEmail, SellerPaymentOption)
VALUES
('Imran Zafar', 'imran.zafar', 'pass123', 'imran.zafar@gmail.com', 'Credit Card'),
('Maria Iqbal', 'maria.iqbal', 'pass123', 'maria.iqbal@yahoo.com', 'PayPal'),
('Arsalan Khan', 'arsalan.khan', 'pass123', 'arsalan.khan@hotmail.com', 'Online Transfer'),
('Saima Ahmed', 'saima.ahmed', 'pass123', 'saima.ahmed@gmail.com', 'Cash on Delivery'),
('Farhan Aziz', 'farhan.aziz', 'pass123', 'farhan.aziz@gmail.com', 'Debit Card'),
('Nadia Rehman', 'nadia.rehman', 'pass123', 'nadia.rehman@yahoo.com', 'Credit Card'),
('Shahbaz Ali', 'shahbaz.ali', 'pass123', 'shahbaz.ali@gmail.com', 'PayPal'),
('Uzma Khalid', 'uzma.khalid', 'pass123', 'uzma.khalid@hotmail.com', 'Online Transfer'),
('Kamran Saeed', 'kamran.saeed', 'pass123', 'kamran.saeed@gmail.com', 'Cash on Delivery'),
('Hina Tariq', 'hina.tariq', 'pass123', 'hina.tariq@gmail.com', 'Debit Card'),
('Zeeshan Anwar', 'zeeshan.anwar', 'pass123', 'zeeshan.anwar@gmail.com', 'Credit Card'),
('Rabia Ahmed', 'rabia.ahmed', 'pass123', 'rabia.ahmed@yahoo.com', 'PayPal'),
('Fahad Bashir', 'fahad.bashir', 'pass123', 'fahad.bashir@gmail.com', 'Online Transfer'),
('Mariam Younas', 'mariam.younas', 'pass123', 'mariam.younas@gmail.com', 'Cash on Delivery'),
('Omer Siddiqui', 'omer.siddiqui', 'pass123', 'omer.siddiqui@hotmail.com', 'Debit Card'),
('Mehwish Ali', 'mehwish.ali', 'pass123', 'mehwish.ali@yahoo.com', 'Credit Card'),
('Bilal Hussain', 'bilal.hussain', 'pass123', 'bilal.hussain@gmail.com', 'PayPal'),
('Kiran Farooq', 'kiran.farooq', 'pass123', 'kiran.farooq@gmail.com', 'Online Transfer'),
('Adnan Malik', 'adnan.malik', 'pass123', 'adnan.malik@gmail.com', 'Cash on Delivery'),
('Lubna Tariq', 'lubna.tariq', 'pass123', 'lubna.tariq@gmail.com', 'Debit Card'),
('Ali Raza', 'ali.raza', 'pass123', 'ali.raza@gmail.com', 'Credit Card'),
('Fiza Khan', 'fiza.khan', 'pass123', 'fiza.khan@yahoo.com', 'PayPal'),
('Tariq Javed', 'tariq.javed', 'pass123', 'tariq.javed@hotmail.com', 'Online Transfer'),
('Sana Aamir', 'sana.aamir', 'pass123', 'sana.aamir@gmail.com', 'Cash on Delivery'),
('Adeel Anwar', 'adeel.anwar', 'pass123', 'adeel.anwar@gmail.com', 'Debit Card'),
('Zara Saeed', 'zara.saeed', 'pass123', 'zara.saeed@yahoo.com', 'Credit Card'),
('Hamza Khalid', 'hamza.khalid', 'pass123', 'hamza.khalid@gmail.com', 'PayPal'),
('Farah Zafar', 'farah.zafar', 'pass123', 'farah.zafar@gmail.com', 'Online Transfer'),
('Tanveer Ali', 'tanveer.ali', 'pass123', 'tanveer.ali@gmail.com', 'Cash on Delivery'),
('Nazia Rehman', 'nazia.rehman', 'pass123', 'nazia.rehman@yahoo.com', 'Debit Card'),
('Imran Shah', 'imran.shah', 'pass123', 'imran.shah@gmail.com', 'Credit Card'),
('Hira Nadeem', 'hira.nadeem', 'pass123', 'hira.nadeem@gmail.com', 'PayPal'),
('Shahid Iqbal', 'shahid.iqbal', 'pass123', 'shahid.iqbal@yahoo.com', 'Online Transfer'),
('Sidra Anwar', 'sidra.anwar', 'pass123', 'sidra.anwar@gmail.com', 'Cash on Delivery'),
('Saad Akhtar', 'saad.akhtar', 'pass123', 'saad.akhtar@gmail.com', 'Debit Card'),
('Ayesha Malik', 'ayesha.malik', 'pass123', 'ayesha.malik@yahoo.com', 'Credit Card'),
('Umer Tariq', 'umer.tariq', 'pass123', 'umer.tariq@gmail.com', 'PayPal'),
('Fatima Anwar', 'fatima.anwar', 'pass123', 'fatima.anwar@gmail.com', 'Online Transfer'),
('Muneeb Zafar', 'muneeb.zafar', 'pass123', 'muneeb.zafar@gmail.com', 'Cash on Delivery'),
('Arfa Hussain', 'arfa.hussain', 'pass123', 'arfa.hussain@gmail.com', 'Debit Card'),
('Waqas Ali', 'waqas.ali', 'pass123', 'waqas.ali@yahoo.com', 'Credit Card'),
('Nabeel Ahmed', 'nabeel.ahmed', 'pass123', 'nabeel.ahmed@gmail.com', 'PayPal'),
('Shaista Javed', 'shaista.javed', 'pass123', 'shaista.javed@hotmail.com', 'Online Transfer'),
('Talha Saeed', 'talha.saeed', 'pass123', 'talha.saeed@gmail.com', 'Cash on Delivery'),
('Muzammil Bashir', 'muzammil.bashir', 'pass123', 'muzammil.bashir@gmail.com', 'Debit Card'),
('Hassan Tariq', 'hassan.tariq', 'pass123', 'hassan.tariq@gmail.com', 'Credit Card'),
('Asma Khalid', 'asma.khalid', 'pass123', 'asma.khalid@gmail.com', 'PayPal');

INSERT INTO Seller (SellerName, SellerUsername, SellerPassword, SellerEmail, SellerPaymentOption)
VALUES
('Absir Ahmed', 'absir', 'pass123', 'absir@gmail.com', 'PayPal'),
('Affan Khan', 'affan', 'pass123', 'affan@gmail.com', 'PayPal'),
('Fahd Ahmed', 'fahd', 'pass123', 'fahd@gmail.com', 'Credit Card');

CREATE TABLE Admin (
    AdminID INT PRIMARY KEY IDENTITY(1,1),
    AdminName NVARCHAR(100) NOT NULL,
    AdminUsername NVARCHAR(50) UNIQUE NOT NULL,
    AdminPassword NVARCHAR(255) NOT NULL,
    AdminEmail NVARCHAR(100) NOT NULL
);
INSERT INTO Admin (AdminName, AdminUsername, AdminPassword, AdminEmail)
VALUES
('Ali Asghar', 'ali.asghar', 'pass123', 'ali.asghar@gmail.com');


CREATE TABLE [Order] (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    ProductID INT FOREIGN KEY REFERENCES Product(ProductID),
    CustomerID INT FOREIGN KEY REFERENCES Customer(CustomerID),
    OrderDate DATETIME NOT NULL,
    Status NVARCHAR(50),
    TotalPrice DECIMAL(10, 2) NOT NULL,
    PaymentMethod NVARCHAR(50) NOT NULL
);

CREATE TABLE OrderHistory (
    OrderHistoryID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT FOREIGN KEY REFERENCES [Order](OrderID) ON DELETE CASCADE,
    CustomerID INT FOREIGN KEY REFERENCES Customer(CustomerID),
    ProductID INT FOREIGN KEY REFERENCES Product(ProductID),
    Bill DECIMAL(10, 2) NOT NULL,
    OrderDate DATETIME NOT NULL
);

CREATE TABLE OrderDetails (
    OrderDetailsID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT FOREIGN KEY REFERENCES [Order](OrderID) ON DELETE CASCADE,
    ProductID INT FOREIGN KEY REFERENCES Product(ProductID),
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(10, 2) NOT NULL,
    TotalPrice DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Product (
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    SellerID INT FOREIGN KEY REFERENCES Seller(SellerID),
    CategoryID INT FOREIGN KEY REFERENCES Category(CategoryID),
    Image_url NVARCHAR(255),
    UnitPrice DECIMAL(10, 2) NOT NULL,
    Quantity INT NOT NULL,
    Brand NVARCHAR(100),
    ShippingOptions NVARCHAR(100),
    Rating DECIMAL(3, 2)
);
ALTER TABLE Product
ADD ProductName NVARCHAR(255) NOT NULL;

delete from Product

select * from Product

INSERT INTO Product (SellerID, CategoryID, Image_url, UnitPrice, Quantity, Brand, ShippingOptions, Rating, ProductName)
VALUES
(1, 1, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\1.jpeg', 199.99, 100, 'Samsung', 'Free Shipping', 4.5, 'Driller'), --electronics
(2, 2, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\2.png', 49.99, 200, 'Nike', 'Standard Shipping', 4.2, 'Women Shoes'), --clothing
(3, 3, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\3.jpeg', 299.99, 50, 'LG', 'Free Shipping', 4.7, 'LG TV'),       --home appliance
(4, 4, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\4.jpeg', 15.99, 500, 'Nivea', 'Free Shipping', 4.0, 'Body Lotion'),    --beauty   
(5, 5, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\5.jpeg', 399.99, 75, 'Decathlon', 'Standard Shipping', 4.3, 'Gloves'),  --sports
(6, 6, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\6.jpeg', 9.99, 150, 'Penguin Books', 'Free Shipping', 4.8, 'Novels'),   --books
(7, 7, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\7.jpg', 19.99, 300, 'Lego', 'Standard Shipping', 4.6, 'Legos'),       --toys 
(8, 8, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\8.jpeg', 149.99, 60, 'Ikea', 'Free Shipping', 4.4, 'Couch'),           --furniture 
(9, 9, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\9.png', 49.99, 200, 'Nestle', 'Standard Shipping', 4.3, 'Juice Carton'),     --groceries 
(10, 10, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\10.jpeg', 399.99, 25, 'Bosch', 'Free Shipping', 4.7, 'Saw'),       --automotive
(11, 12, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\11.jpeg', 99.99, 150, 'Pandora', 'Standard Shipping', 4.6, 'Bracelet'), --jewellery
(12, 13, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\12.jpeg', 10.99, 500, 'Huggies', 'Free Shipping', 4.5, 'Soft Pampers'),    --baby products
(13, 14, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\13.jpg', 699.99, 50, 'Apple', 'Standard Shipping', 4.8, 'iPhone 16'),  --mobile
(14, 15, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\14.jpg', 89.99, 100, 'Dell', 'Free Shipping', 4.4, 'Dell 87x'),       --laptops   
(15, 16, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\15.jpeg', 199.99, 60, 'Rolex', 'Standard Shipping', 4.9, 'Gigante Edition'),  --watches
(16, 1, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\16.jpeg', 49.99, 200, 'Sony', 'Free Shipping', 4.2, 'Sony A7'),         
(17, 17, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\17.jpg', 79.99, 100, 'Cannon', 'Standard Shipping', 4.6, 'SneakerX'),
(18, 19, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\18.jpeg', 29.99, 300, 'Fender', 'Free Shipping', 4.7, 'Electric Guitar'),
(19, 17, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\19.jpeg', 59.99, 150, 'Vans', 'Standard Shipping', 4.3, 'Old Skool'),
(20, 48, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\20.jpeg', 99.99, 250, 'Intex', 'Free Shipping', 4.5, 'Kids Pool'),
(21, 14, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\21.jpeg', 229.99, 120, 'Huawei', 'Free Shipping', 4.2, 'Huawei x30'),
(22, 27, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\22.jpeg', 29.99, 250, 'Adidas', 'Standard Shipping', 4.4, 'Adidas Sambas'),
(23, 21, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\23.jpeg', 349.99, 80, 'Whirlpool', 'Free Shipping', 4.5, 'Fridge'),
(24, 4, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\24.jpg', 12.99, 300, 'Olay', 'Standard Shipping', 4.1, 'Olay Lotion'),
(25, 5, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\25.jpeg', 549.99, 40, 'Nike', 'Free Shipping', 4.7, 'Hypervenoms'),
(26, 6, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\26.jpeg', 25.99, 100, 'Harper Collins', 'Standard Shipping', 4.8, 'Books HC'),
(27, 7, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\27.jpeg', 14.99, 150, 'Mattel', 'Free Shipping', 4.2, 'Dolls'),
(28, 8, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\28.jpeg', 89.99, 60, 'Wayfair', 'Standard Shipping', 4.4, 'Sofa'),
(29, 25, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\29.jpg', 15.99, 400, 'Pepsi', 'Free Shipping', 4.3, 'Pepis 350ml'),
(30, 10, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\30.png', 459.99, 30, 'Makita', 'Standard Shipping', 4.7, 'Auto Drill'),
(31, 11, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\31.jpeg', 129.99, 100, 'Tiffany', 'Free Shipping', 4.9, 'HealthCare'),
(32, 13, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\32.jpeg', 12.99, 350, 'Pampers', 'Standard Shipping', 4.6, 'Pampers Kids'),
(33, 14, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\33.jpeg', 999.99, 20, 'Sony', 'Free Shipping', 4.5, 'Xperia'),
(34, 15, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\34.jpeg', 199.99, 70, 'Asus', 'Standard Shipping', 4.8, 'Asus A11'),
(35, 16, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\35.jpeg', 299.99, 50, 'Omega', 'Free Shipping', 4.7, 'Omega Gold Ed'),
(36, 1, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\36.jpg', 129.99, 100, 'JBL', 'Standard Shipping', 4.4, 'JBL LoudZ'),
(37, 17, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\37.jpeg', 149.99, 50, 'Yamaha', 'Free Shipping', 4.6, 'Yamaha Rider Shoes'),
(38, 18, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\38.jpeg', 40.99, 200, 'Taylor', 'Standard Shipping', 4.5, 'Cleaning'),
(39, 2, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\39.jpge', 39.99, 300, 'Nike', 'Free Shipping', 4.3, 'Nike Hoodie'),
(40, 16, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\40.jpg', 119.99, 150, 'Seiko', 'Standard Shipping', 4.6, 'Seiko Elixir'),
(41, 14, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\41.jpeg', 249.99, 120, 'OnePlus', 'Free Shipping', 4.4, 'OnePlus +'),
(42, 17, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\42.jpeg', 34.99, 220, 'Reebok', 'Standard Shipping', 4.2, 'Reebok Olds'),
(43, 14, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\43.jpeg', 249.99, 90, 'Samsung', 'Free Shipping', 4.5, 'Samsung s3'),
(44, 4, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\44.jpeg', 16.99, 350, 'Dove', 'Standard Shipping', 4.4, 'Dove Shampoo'),
(45, 5, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\45.jpeg', 299.99, 45, 'Under Armour', 'Free Shipping', 4.6, 'UA Compression'),
(46, 9, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\46.jpeg', 30.99, 200, 'Random House', 'Standard Shipping', 4.3, 'RH Book'),
(47, 7, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\47.jpeg', 17.99, 180, 'Hot Wheels', 'Free Shipping', 4.5, 'Hot Wheels'),
(48, 11, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\48.jepg', 129.99, 80, 'Pottery Barn', 'Standard Shipping', 4.2, 'Bed'),
(49, 25, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\49.jpeg', 24.99, 500, 'Coca-Cola', 'Free Shipping', 4.3, 'Coke'),
(50, 10, 'C:\\Users\\absir\\Desktop\\uni\\5th sem\\DB\\final project\\50.jpeg', 349.99, 60, 'Makita', 'Standard Shipping', 4.7, 'Generator');


CREATE TABLE Category (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    CategoryName NVARCHAR(100) NOT NULL
);
INSERT INTO Category (CategoryName)
VALUES
('Electronics'), -- 1
('Clothing'), -- 2
('Home Appliances'), -- 3
('Beauty & Personal Care'), -- 4
('Sports & Fitness'), -- 5
('Books'), -- 6
('Toys & Games'), -- 7
('Furniture'), -- 8
('Groceries'), -- 9
('Automotive'), -- 10
('Health'), -- 11
('Jewelry'), -- 12
('Baby Products'), -- 13
('Mobile Phones'), -- 14
('Computers & Laptops'), -- 15
('Watches'), -- 16
('Footwear'), -- 17
('Accessories'), -- 18
('Musical Instruments'), -- 19
('Pet Supplies'), -- 20
('Kitchen Appliances'), -- 21
('Home Decor'), -- 22
('Stationery'), -- 23
('Gifts & Crafts'), -- 24
('Food & Beverages'), -- 25
('Office Supplies'), -- 26
('Video Games'), -- 27
('Smart Home Devices'), -- 28
('Travel & Luggage'), -- 29
('Photography'), -- 30
('Camping & Hiking'), -- 31
('Tools & Hardware'), -- 32
('Outdoor Furniture'), -- 33
('Party Supplies'), -- 34
('Construction Materials'), -- 35
('Handbags & Wallets'), -- 36
('Cosmetics'), -- 37
('Fragrances'), -- 38
('Smartwatches'), -- 39
('Car Accessories'), -- 40
('Bedding & Linens'), -- 41
('Art & Collectibles'), -- 42
('Laptops & Tablets'), -- 43
('Vitamins & Supplements'), -- 44
('Fitness Equipment'), -- 45
('Muscle Building Supplements'), -- 46
('Sunglasses'), -- 47
('Swimming Gear'), -- 48
('Luxury Goods'), -- 49
('Gourmet Food'), -- 50
('Office Furniture'); -- 51



CREATE TABLE WishList (
    WishListID INT PRIMARY KEY IDENTITY(1,1),
    ProductID INT FOREIGN KEY REFERENCES Product(ProductID),
    SellerID INT FOREIGN KEY REFERENCES Seller(SellerID),
    CategoryID INT FOREIGN KEY REFERENCES Category(CategoryID),
    CustomerID INT FOREIGN KEY REFERENCES Customer(CustomerID),
    Image_url NVARCHAR(255),
    UnitPrice DECIMAL(10, 2) NOT NULL,
    Quantity INT NOT NULL,
    Brand NVARCHAR(100),
    ShippingOptions NVARCHAR(100)
);

CREATE TABLE Review (
    ReviewID INT PRIMARY KEY IDENTITY(1,1),
    ProductID INT FOREIGN KEY REFERENCES Product(ProductID),
    CustomerID INT FOREIGN KEY REFERENCES Customer(CustomerID),
    Rating INT CHECK (Rating BETWEEN 1 AND 5),
    Review_txt NVARCHAR(1000)
);

CREATE TABLE Cart (
    CartID INT PRIMARY KEY IDENTITY(1,1),
    ProductID INT FOREIGN KEY REFERENCES Product(ProductID),
    CustomerID INT FOREIGN KEY REFERENCES Customer(CustomerID),
    Quantity INT NOT NULL
);